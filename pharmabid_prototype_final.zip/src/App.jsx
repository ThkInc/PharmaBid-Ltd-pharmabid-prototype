
import React, { useState, useEffect, useRef } from "react";

export default function App(){
  const [role, setRole] = useState("retailer");
  const [soundOn, setSoundOn] = useState(true);
  const [notifications, setNotifications] = useState([]);
  const [orders, setOrders] = useState([{
    id: "ord-001",
    item_name: "Amoxicillin 500mg Capsules",
    quantity: 1000,
    target_price: 85.0,
    status: "open",
    posted_at: new Date().toISOString()
  }]);
  const [bids, setBids] = useState([
    { id: "bid-1", order_id: "ord-001", supplier_name: "Kentamed Distributors", price: 79.0, delivery_days: 3, status: "pending" },
    { id: "bid-2", order_id: "ord-001", supplier_name: "BioCare Pharma", price: 81.0, delivery_days: 1, status: "pending" },
    { id: "bid-3", order_id: "ord-001", supplier_name: "MedSource Ltd", price: 82.5, delivery_days: 2, status: "pending" }
  ]);

  const audioRef = useRef(null);
  useEffect(()=> {
    audioRef.current = new Audio('/public/sounds/ding.wav');
  },[]);

  useEffect(()=>{
    setNotifications([{id:"n1", message:"Sample order loaded: Amoxicillin 500mg (1,000 packs)", created_at:new Date().toISOString()}]);
  },[]);

  function playDing(){
    if(!soundOn || !audioRef.current) return;
    try { audioRef.current.currentTime = 0; audioRef.current.play(); } catch(e){}
  }

  function acceptBid(bidId){
    const bid = bids.find(b=>b.id===bidId);
    if(!bid) return;
    setBids(bs => bs.map(b => b.id===bidId ? {...b, status:"accepted"} : b));
    setOrders(os => os.map(o => o.id===bid.order_id ? {...o, status:"awarded"} : o));
    const amount = (bid.price * (orders.find(o=>o.id===bid.order_id)?.quantity || 1));
    setTimeout(()=>{
      setNotifications(n => [{id:"n-pay", message:`Payment successful — KES ${amount.toLocaleString()} released to ${bid.supplier_name}`, created_at:new Date().toISOString()}, ...n]);
      setOrders(os => os.map(o=> o.id===bid.order_id ? {...o, status:"fulfilled"} : o));
      playDing();
    }, 1200);
  }

  function autoSubmitBids(){
    setTimeout(()=> setBids(bs=> [{ id: "bid-4", order_id: "ord-001", supplier_name: "Kentamed Distributors", price: 79.0, delivery_days: 3, status: "pending" }, ...bs]), 300);
    setTimeout(()=> setBids(bs=> [{ id: "bid-5", order_id: "ord-001", supplier_name: "BioCare Pharma", price: 81.0, delivery_days: 1, status: "pending" }, ...bs]), 700);
    setTimeout(()=> { setNotifications(n=> [{id:"n-auto", message:"Auto bids submitted", created_at:new Date().toISOString()}, ...n]); playDing(); }, 900);
  }

  return (
    <div>
      <header className="header">
        <div className="brand">PharmaBid</div>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <div>
            <label style={{marginRight:8}}>Sound</label>
            <button className="button" onClick={()=> setSoundOn(s=>!s)}>{soundOn ? "On" : "Off"}</button>
          </div>
          <div>
            <label style={{marginRight:8}}>View as</label>
            <select value={role} onChange={(e)=>setRole(e.target.value)}>
              <option value="retailer">Retailer</option>
              <option value="supplier">Supplier</option>
            </select>
          </div>
        </div>
      </header>

      <div className="layout">
        <main style={{flex:1}}>
          {role==="retailer" ? (
            <div className="panel">
              <h2>Retailer Dashboard</h2>
              <div className="small">Orders</div>
              {orders.map(o=>(
                <div key={o.id} style={{border:"1px solid #e6eefb", padding:12, marginBottom:8}}>
                  <div style={{fontWeight:600}}>{o.item_name}</div>
                  <div className="small">Qty: {o.quantity} • Target KES {o.target_price}</div>
                  <div style={{marginTop:8}}>Status: <strong>{o.status}</strong></div>
                </div>
              ))}
              <div className="small">Bids</div>
              <table style={{width:"100%", borderCollapse:"collapse"}}>
                <thead><tr><th>Supplier</th><th>Price</th><th>Delivery</th><th>Action</th></tr></thead>
                <tbody>
                  {bids.sort((a,b)=>a.price-b.price).map(b=>(
                    <tr key={b.id} style={{borderBottom:"1px solid #f1f7ff"}}>
                      <td style={{padding:8}}>{b.supplier_name}</td>
                      <td>{b.price.toFixed(2)}</td>
                      <td>{b.delivery_days} days</td>
                      <td>{b.status!=="accepted" && orders.find(o=>o.id===b.order_id).status==="open" ? <button className="button" onClick={()=>acceptBid(b.id)}>Accept</button> : <span>{b.status}</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="panel">
              <h2>Supplier Dashboard</h2>
              <div className="small">Open Orders</div>
              {orders.filter(o=>o.status==="open").map(o=>(
                <div key={o.id} style={{border:"1px solid #e6eefb", padding:12, marginBottom:8}}>
                  <div style={{fontWeight:600}}>{o.item_name}</div>
                  <div className="small">Qty: {o.quantity} • Target KES {o.target_price}</div>
                  <div style={{marginTop:8}}><button className="button" onClick={()=>{ setBids(bs=> [{ id: "bid-"+Math.random().toString(36).slice(2,6), order_id: o.id, supplier_name: "New Supplier", price: o.target_price-3, delivery_days:2, status:"pending"}, ...bs]); setNotifications(n=> [{id:"n-new", message:"Your bid was submitted", created_at:new Date().toISOString()}, ...n]); playDing(); }}>Quick bid</button></div>
                </div>
              ))}
              <div className="small">Your bids</div>
              {bids.filter(b=>b.supplier_name==="MedSource Ltd").map(b=>(
                <div key={b.id} style={{padding:8,border:"1px solid #f1f7ff", marginBottom:6}}>{b.supplier_name} — KES {b.price.toFixed(2)}</div>
              ))}
            </div>
          )}
        </main>

        <aside style={{width:320}}>
          <div className="panel">
            <h4>Notifications</h4>
            {notifications.map(n=>(
              <div key={n.id} style={{padding:8,borderBottom:"1px solid #f1f7ff"}}>{n.message}<div style={{color:"#94a3b8",fontSize:12}}>{new Date(n.created_at).toLocaleString()}</div></div>
            ))}
          </div>
          <div style={{height:12}}/>
          <div className="panel">
            <h4>Quick actions</h4>
            <button className="button" onClick={autoSubmitBids}>Auto-submit sample bids</button>
          </div>
        </aside>
      </div>

      <footer className="footer">PharmaBid prototype — PharmaBid Ltd</footer>
    </div>
  );
}
