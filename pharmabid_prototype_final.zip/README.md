# pharmabid-prototype

**PharmaBid Ltd** — clickable frontend prototype (Retailer & Supplier dashboards)

This repository contains a frontend-only interactive prototype for PharmaBid (blue & white theme).
It auto-loads a sample order (Amoxicillin 500mg) and 3 sample bids so the UI appears live.

## Preview screenshots

![Retailer dashboard](public/screens/retailer_dashboard.png)
![Supplier dashboard](public/screens/supplier_dashboard.png)
![Notifications](public/screens/notifications.png)
![Payment confirmation](public/screens/payment_confirmation.png)

---

## Quick start (local)

1. Install Node.js (v18+) and npm.
2. Run:
```bash
git clone https://github.com/PharmaBid-Ltd/pharmabid-prototype
cd pharmabid-prototype
npm install
npm run dev
```
3. Open `http://localhost:5173`

---

## One-click deploy (Vercel)

Click the button below to deploy to Vercel (connect your GitHub account when prompted):

[![Deploy to Vercel](https://vercel.com/button)](https://vercel.com/new/import?repository-url=https://github.com/PharmaBid-Ltd/pharmabid-prototype)

---

## About
Author: PharmaBid Ltd

This is a frontend prototype only — no real payments or user data are processed.
